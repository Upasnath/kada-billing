// Phone-side layer for Kada Billing: keeps all data on this phone,
// and saves/shares PDF and backup files through Android.
import { jsPDF } from "jspdf";
import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

window.jspdf = { jsPDF };

const KEY = "kadabill-store-v1";
let store = {};
try { store = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { store = {}; }
const listeners = new Set();

// Mirror of the data in the app's own files folder. Android's backup to the
// phone owner's Google account includes this folder, so a new phone signed in
// with the same Gmail gets the bills back when the app is reinstalled.
const NATIVE = Capacitor.isNativePlatform();
const FILE = { path: "kada-store.json", directory: Directory.Data, encoding: Encoding.UTF8 };
let fileTimer = null;
async function saveFile() {
  clearTimeout(fileTimer); fileTimer = null;
  if (!NATIVE) return;
  try { await Filesystem.writeFile({ ...FILE, data: JSON.stringify(store) }); } catch (e) { console.error("file save failed", e); }
}
function notify() { for (const l of listeners) l(); }
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { console.error(e); }
  clearTimeout(fileTimer); fileTimer = setTimeout(saveFile, 600);
  notify();
}
document.addEventListener("visibilitychange", () => { if (document.hidden && fileTimer) saveFile(); });
if (NATIVE) {
  Filesystem.readFile(FILE).then((r) => {
    const fromFile = JSON.parse(r.data || "{}") || {};
    if (!Object.keys(store).length && Object.keys(fromFile).length) {
      store = fromFile;
      try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {}
      notify();
    } else if (Object.keys(store).length) saveFile();
  }).catch(() => { if (Object.keys(store).length) saveFile(); });
}
const parent = (p) => p.split("/").slice(0, -1).join("/");
const last = (p) => p.split("/").pop();
const mkId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

function docSnap(path) {
  const d = store[path];
  return { id: last(path), exists: !!d, data: () => (d ? JSON.parse(JSON.stringify(d)) : undefined), metadata: { fromCache: false, hasPendingWrites: false } };
}
function docRef(path) {
  return {
    id: last(path), path,
    get: async () => docSnap(path),
    set: async (data) => { store[path] = JSON.parse(JSON.stringify(data)); persist(); },
    update: async (data) => { store[path] = { ...(store[path] || {}), ...data }; persist(); },
    delete: async () => { delete store[path]; persist(); },
    onSnapshot(next) { const f = () => next(docSnap(path)); listeners.add(f); setTimeout(f, 0); return () => listeners.delete(f); },
    collection: (c) => colRef(path + "/" + c),
  };
}
function colSnap(path) {
  const docs = Object.keys(store).filter((k) => parent(k) === path).sort().map(docSnap);
  return { docs, size: docs.length, empty: !docs.length, docChanges: () => [], metadata: { fromCache: false, hasPendingWrites: false } };
}
function colRef(path) {
  return {
    path,
    doc: (id) => docRef(path + "/" + (id || mkId())),
    add: async (data) => { const r = docRef(path + "/" + mkId()); await r.set(data); return r; },
    get: async () => colSnap(path),
    onSnapshot(next) { const f = () => next(colSnap(path)); listeners.add(f); setTimeout(f, 0); return () => listeners.delete(f); },
  };
}
const db = { doc: docRef, collection: colRef };

function blobToBase64(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(",")[1]);
    r.onerror = rej;
    r.readAsDataURL(blob);
  });
}
const downloads = {
  async save({ filename, data }) {
    const blob = data instanceof Blob ? data : new Blob([data]);
    if (Capacitor.isNativePlatform()) {
      const b64 = await blobToBase64(blob);
      const w = await Filesystem.writeFile({ path: filename, data: b64, directory: Directory.Cache });
      try {
        await Share.share({ title: filename, files: [w.uri], dialogTitle: "Save or send " + filename });
      } catch (e) {
        if (/cancel/i.test(String(e && e.message))) throw { code: "declined", message: "cancelled" };
        throw e;
      }
      return { status: "saved" };
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    return { status: "saved" };
  },
};

// Backup / restore of everything on this phone
window.kadaBackup = {
  exportJson: () => JSON.stringify({ app: "kada-billing", version: 1, savedAt: new Date().toISOString(), store }),
  importJson(text) {
    const o = JSON.parse(text);
    if (!o || o.app !== "kada-billing" || typeof o.store !== "object") throw new Error("Not a Kada Billing backup file");
    store = o.store; persist();
  },
};

window.claude = {
  use: async (name) => (name === "db" ? db : name === "downloads" ? downloads : null),
};
