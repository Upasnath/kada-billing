# Kada Billing

Billing app for two shops: **Juice Bar Cafe** and **Furniture Shop**.

- Add items with prices, tick items to make a bill, PDF bill (save or share to WhatsApp)
- Purchases, weekly / monthly / yearly reports
- All data stays on the phone; use **Reports → Backup** to save a copy

## Getting the APK
Every push to `main` builds the website (GitHub Pages: https://upasnath.github.io/kada-billing/) and the app on GitHub Actions and publishes it under
**Releases → test-build → kada-billing.apk**. Open that link on the Android phone and install.

## Project layout
- `www/index.html` – styles and page shell
- `www/app.js` – the app: shop registration, login, roles, billing, items, purchases, reports
- `src/native.js` – on-phone storage, PDF and sharing (bundled to `www/native.js`)
- `android/` – Android project (Capacitor)
