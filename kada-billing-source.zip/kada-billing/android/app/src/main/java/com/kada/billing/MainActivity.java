package com.kada.billing;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
